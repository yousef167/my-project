extends Node

var points = 0
var time_passed = 0.0

@onready var points_label = %Label


func _process(delta):
	time_passed += delta


func add_point():
	points += 1
	
	if points_label:
		points_label.text = "Points: " + str(points)


func reset():
	points = 0
	time_passed = 0.0
