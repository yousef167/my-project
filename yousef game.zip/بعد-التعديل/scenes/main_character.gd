extends CharacterBody2D

const SPEED = 200.0
const JUMP_VELOCITY = -300.0

@onready var sprite = $Sprite2D

func _ready() -> void:
	Global.Health = 3
var gravity = ProjectSettings.get_setting("physics/2d/default_gravity")
var LastHealth = Global.Health

func _process(delta: float) -> void:
	if LastHealth != Global.Health:
		take_damage()
		LastHealth = Global.Health
		
func _physics_process(delta):
	
	# الجاذبية
	if not is_on_floor():
		velocity.y += gravity * delta

	# القفز
	if Input.is_key_pressed(KEY_SPACE) and is_on_floor():
		velocity.y = JUMP_VELOCITY

	# الحركة
	var direction = 0

	if Input.is_key_pressed(KEY_A):
		direction -= 1

	if Input.is_key_pressed(KEY_D):
		direction += 1

	# تحريك يمين ويسار
	if direction != 0:
		velocity.x = direction * SPEED
	else:
		velocity.x = move_toward(velocity.x, 0, 20)

	# الأنيميشن
	if not is_on_floor():
		sprite.animation = "jumping"
	elif abs(velocity.x) > 1:
		sprite.animation = "running"
	else:
		sprite.animation = "default"

	# تحريك اللاعب
	move_and_slide()

	# شقلبة الشخصية
	if velocity.x != 0:
		sprite.flip_h = velocity.x < 0

#قلوب الشخصية


@onready var heart1: TextureRect = $"../../ui/Panel/CanvasLayer/heart1"
@onready var heart2: TextureRect = $"../../ui/Panel/CanvasLayer/heart2"
@onready var heart3: TextureRect = $"../../ui/Panel/CanvasLayer/heart3"


func take_damage():
	print("PlayerDamaged")



	if Global.Health == 2:
		heart3.hide()

	elif Global.Health == 1:
		heart2.hide()

	elif Global.Health == 0:
		heart1.hide()
		get_tree().reload_current_scene()
