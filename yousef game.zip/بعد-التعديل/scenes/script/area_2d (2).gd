extends Area2D

@onready var game_manager = %GameManager


func _on_body_entered(body):
	if body is CharacterBody2D:
		GameManager.add_point()
		game_manager.add_point()

		var sound = AudioStreamPlayer.new()
		sound.stream = preload("res://scenes/sound/chieuk-coin-257878.mp3")

		get_tree().current_scene.add_child(sound)

		sound.play()

		hide()
		$CollisionShape2D.set_deferred("disabled", true)

		queue_free()
