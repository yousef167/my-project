extends Node




func _on_button_pressed() -> void:
	get_tree().change_scene_to_file("res://scenes/levels/main game.tscn")


func _on_button_2_pressed() -> void:
	get_tree().change_scene_to_file("res://scenes/levels/level3.tscn")



func _on_ready() -> void:
	$Label2.text = "Score: " + str(GameManager.points) + "points"

	$Label3.text = "Time: " + str(round(GameManager.time_passed)) + "s"
