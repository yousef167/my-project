extends Label

@export var timer :Timer

# حط مسار الصفحة هون
var next_scene = ("res://scenes/levels/game over.tscn")

func _ready():
	timer.timeout.connect(_on_timer_timeout)
	timer.start()
	
func _process(delta: float) -> void:
	self.text = str(round(timer.time_left))

func _on_timer_timeout():
	get_tree().change_scene_to_file("res://scenes/levels/game over.tscn")
