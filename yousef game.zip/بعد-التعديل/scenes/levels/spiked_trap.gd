extends Area2D

var speed = 250
var direction = Vector2.RIGHT

func _ready():
	body_entered.connect(_on_body_entered)

func _process(delta):
	position += direction * speed * delta

func _on_body_entered(body):
	# إذا ضرب جدار اعكس الاتجاه
	direction.x *= -1
	if body.is_in_group("Player"):
		Global.Health -= 1
