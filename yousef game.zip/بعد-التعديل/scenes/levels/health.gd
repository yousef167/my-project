extends HBoxContainer



@onready var heart1 = $"../heart1"
@onready var heart2 = $"../heart2"
@onready var heart3 = $"../heart3"

func take_damage():

	Global.health -= 1

	if Global.health == 2:
		heart3.hide()

	elif Global.health == 1:
		heart2.hide()

	elif Global.health == 0:
		heart1.hide()
		get_tree().reload_current_scene()
